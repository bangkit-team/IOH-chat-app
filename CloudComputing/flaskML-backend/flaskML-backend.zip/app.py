from flask import Flask, request
import tensorflow as tf
import numpy as np

app = Flask(__name__)


model = tf.keras.models.load_model("saved_model")


@app.route('/', methods=['GET'])
def home():
    return "success"


@app.route('/nonchat', methods=['POST'])
def nonchat():
    # image = request.form['image']
    # print(image)
    path = "img\sschat.png"
    img = tf.keras.preprocessing.image.load_img(
        path, color_mode="rgb", target_size=(224, 224))
    x = tf.keras.preprocessing.image.img_to_array(img)
    x /= 255
    x = np.expand_dims(x, axis=0)
    images = np.vstack([x])

    # lebih dari 0.5 = non chat
    # kurang dari 0.5 = chat
    # output string
    hasil = model.predict(images)
    hasil = str(hasil[0][0])
    print(hasil)
    return "success"


@app.route('/speech', methods=['GET'])
def speech():
    return "Flask server for /speech"


@app.route('/translate', methods=['GET'])
def translatetext():
    return "Flask server for /translate text"


if __name__ == "__main__":
    app.run(port=5000, debug=True)
