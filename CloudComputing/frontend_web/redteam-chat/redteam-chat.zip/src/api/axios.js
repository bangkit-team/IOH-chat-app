import axios from 'axios';

export default axios.create({
    // baseURL: 'http://localhost:3000'
    baseURL: 'http://34.142.215.198'
});